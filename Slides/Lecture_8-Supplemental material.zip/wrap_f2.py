from ctypes import CDLL, POINTER, c_int, c_double
import numpy as np

fortran = CDLL('./libtest_f2.so')
fortran.risolvi.argtypes = [ POINTER(c_double), 
                                 POINTER(c_double), 
                                 POINTER(c_double),
                                 POINTER(c_int) ]

def risolvi(A, b):
    N = len(b)
    c = np.zeros(N)
    A = np.asfortranarray(A, dtype=c_double)
    b = np.asfortranarray(b, dtype=c_double)
    c = np.asfortranarray(c, dtype=c_double)
    # call Fortran subroutine
    fortran.risolvi( A.ctypes.data_as(POINTER(c_double)), 
                     b.ctypes.data_as(POINTER(c_double)), 
                     c.ctypes.data_as(POINTER(c_double)), 
                     c_int(N) )
    return c

if __name__ == "__main__":
    import numpy as np
    from scipy.linalg import solve
    import time
    
    N = 100
    A = np.random.rand(N,N)
    b = np.random.rand(N)
    c = np.zeros(N)
    #
    # Fortran call
    start = time.time()
    c_f = risolvi(A, b)
    stop = time.time()
    print('Fortran solution took ',stop - start,'seconds')
    #
    # Numpy
    start = time.time()
    c_py = solve(A,b)
    stop = time.time()
    print('Numpy solution  took ',stop - start,'seconds')
    #
    # compare results
    print(np.max(np.abs(c_f-c_py)))



