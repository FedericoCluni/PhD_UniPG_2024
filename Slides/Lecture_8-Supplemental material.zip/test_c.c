/* test_c.c */
/*
  example of a function in C 
  
  compile with: 
  gcc  -shared -fPIC -o libtest_c.so test_c.c 
  
  the wrapper is in test_c.py
*/
double somma(int M, int N, double a[M][N], double b[M][N]) {

    int i, j;
    double s = 0.;
    
    for (i=0; i<M; i++){
        for (j=0;j<N;j++){
            s = s + a[i][j] * b[i][j];
        }
    }
    return s;
}
