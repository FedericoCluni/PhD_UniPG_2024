import numpy as np
import test_f
a = np.random.rand(2,2)
b = np.random.rand(2,2)
print(test_f.moltiplica(a,b))
print(2*(a*b))
